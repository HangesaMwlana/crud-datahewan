CREATE DATABASE IF NOT EXISTS padalarang_petshop;
USE padalarang_petshop;

CREATE TABLE IF NOT EXISTS hewan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_hewan VARCHAR(100) NOT NULL,
    jenis_hewan VARCHAR(100) NOT NULL,
    umur VARCHAR(50),
    keterangan TEXT
);
