<?php 
include "koneksi.php"; 
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM hewan WHERE id='$id'"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data Hewan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2>Edit Data Hewan</h2>

    <form method="POST">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">

        <div class="mb-3">
            <label>Nama Hewan</label>
            <input type="text" name="nama_hewan" class="form-control" value="<?= $data['nama_hewan'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Jenis Hewan</label>
            <input type="text" name="jenis_hewan" class="form-control" value="<?= $data['jenis_hewan'] ?>" required>
        </div>

        <div class="mb-3">
            <label>Umur</label>
            <input type="text" name="umur" class="form-control" value="<?= $data['umur'] ?>">
        </div>

        <div class="mb-3">
            <label>Keterangan</label>
            <textarea name="keterangan" class="form-control"><?= $data['keterangan'] ?></textarea>
        </div>

        <button type="submit" name="update" class="btn btn-warning">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        mysqli_query($koneksi, "UPDATE hewan SET 
            nama_hewan='$_POST[nama_hewan]',
            jenis_hewan='$_POST[jenis_hewan]',
            umur='$_POST[umur]',
            keterangan='$_POST[keterangan]'
            WHERE id='$_POST[id]'");

        echo "<script>alert('Data berhasil diperbarui!'); window.location='index.php';</script>";
    }
    ?>
</div>

</body>
</html>
