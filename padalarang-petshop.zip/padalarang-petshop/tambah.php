<?php include "koneksi.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Hewan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">

<div class="container mt-4">
    <h2>Tambah Hewan Baru</h2>

    <form method="POST">
        <div class="mb-3">
            <label>Nama Hewan</label>
            <input type="text" name="nama_hewan" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Jenis Hewan</label>
            <input type="text" name="jenis_hewan" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Umur</label>
            <input type="text" name="umur" class="form-control">
        </div>

        <div class="mb-3">
            <label>Keterangan</label>
            <textarea name="keterangan" class="form-control"></textarea>
        </div>

        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
        mysqli_query($koneksi, "INSERT INTO hewan (nama_hewan, jenis_hewan, umur, keterangan) VALUES 
        ('$_POST[nama_hewan]', '$_POST[jenis_hewan]', '$_POST[umur]', '$_POST[keterangan]')");
        
        echo "<script>alert('Data berhasil ditambahkan!'); window.location='index.php';</script>";
    }
    ?>
</div>

</body>
</html>
